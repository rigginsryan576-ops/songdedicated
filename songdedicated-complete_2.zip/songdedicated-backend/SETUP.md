# SongDedicated — Launch in 10 Minutes

## What you need (all free to start)
- GitHub account
- Vercel account (vercel.com)
- Stripe account (stripe.com)
- Anthropic API key (console.anthropic.com)
- MusicAPI key (musicapi.ai) — 5 free test generations
- Resend account (resend.com) — 3,000 free emails/month
- Domain: songdedicated.com (~$12/yr on namecheap.com)

---

## Step 1 — Get your API keys (5 min)

| Service | Where to get it | Env var name |
|---|---|---|
| Stripe secret key | stripe.com → Developers → API Keys | STRIPE_SECRET_KEY |
| Stripe webhook secret | (set up in Step 3) | STRIPE_WEBHOOK_SECRET |
| Anthropic | console.anthropic.com → API Keys | ANTHROPIC_API_KEY |
| MusicAPI | musicapi.ai → Dashboard | MUSICAPI_KEY |
| Resend | resend.com → API Keys | RESEND_API_KEY |

---

## Step 2 — Deploy to Vercel (2 min)

1. Upload this folder + `songdedicated.html` to a new GitHub repo
2. Go to vercel.com → "Add New Project" → import your repo
3. In Vercel project settings → **Environment Variables** → add all 4 keys from the table above (leave STRIPE_WEBHOOK_SECRET blank for now)
4. Click **Deploy**

---

## Step 3 — Wire up Stripe webhook (2 min)

1. Go to stripe.com → Developers → Webhooks → **Add endpoint**
2. URL: `https://your-vercel-url.vercel.app/api/webhook`
3. Events to listen for: `payment_intent.succeeded`
4. Copy the **Signing secret** (starts with `whsec_`)
5. Add it to Vercel env vars as `STRIPE_WEBHOOK_SECRET`
6. Redeploy (Vercel → Deployments → Redeploy)

---

## Step 4 — Update the frontend HTML (1 min)

In `songdedicated.html`, find the `handleCheckout()` function and replace the demo simulation with:

```javascript
async function handleCheckout() {
  // ... existing validation ...

  // POST order to your backend
  const res = await fetch('/api/create-payment', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, recipient, occasion, story, genre: selectedGenre, mustInclude })
  });
  const { clientSecret } = await res.json();

  // Confirm payment with Stripe.js
  const stripe = Stripe('pk_live_YOUR_PUBLISHABLE_KEY'); // ← your Stripe publishable key
  const { error } = await stripe.confirmCardPayment(clientSecret, {
    payment_method: {
      card: cardElement, // ← add a Stripe Card Element to your form
      billing_details: { name, email }
    }
  });

  if (!error) {
    // Show success overlay — song generates in background
    document.getElementById('success-overlay').classList.add('show');
  }
}
```

For the card input, add Stripe Elements to your order form. See: stripe.com/docs/stripe-js

---

## Step 5 — Verify your domain email in Resend (1 min)

1. resend.com → Domains → Add Domain → enter `songdedicated.com`
2. Add the DNS records they show you in Namecheap
3. Songs will send from `songs@songdedicated.com`

---

## You're live. Economics:

| | |
|---|---|
| Revenue per song | $99.00 |
| Stripe fee | ~$3.17 |
| Claude API | ~$0.05 |
| MusicAPI | $0.08 |
| Resend | $0.00 (free tier) |
| **Net per song** | **~$95.70** |

First 10 songs = ~$957 profit.
